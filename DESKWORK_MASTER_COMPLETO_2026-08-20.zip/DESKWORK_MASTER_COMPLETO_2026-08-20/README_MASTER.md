# DESKWORK — MASTER PROJECT CONTEXT
## Consolidación histórica, funcional, técnica y operativa

**Versión:** Master Consolidation v1.0  
**Fecha de consolidación:** 2026-08-20  
**Estado:** Documento maestro operativo  
**Propósito:** centralizar el conocimiento recuperable del proyecto DeskWork para que Claude, Minimax, Codex y GPT trabajen sobre una única referencia.

### Importante sobre la procedencia
Esta consolidación se construye con:
- contexto de proyecto disponible;
- conversaciones de DeskWork visibles en el contexto de trabajo;
- decisiones y entregables recuperables;
- la propuesta UI/UX v2.0 de Claude proporcionada en la conversación;
- consolidaciones técnicas y de producto ya producidas.

No se debe interpretar este archivo como una exportación literal de cada mensaje histórico de ChatGPT. Los materiales originales deben conservarse cuando estén disponibles y se deben añadir al `99_SOURCE_ARCHIVE`.

### Jerarquía de autoridad
1. Decisión explícita más reciente del Product Owner.
2. `15_DECISIONS/DECISION_LOG.md`.
3. `02_PRODUCT/PRODUCT_SOURCE_OF_TRUTH.md`.
4. `05_ARCHITECTURE/ARCHITECTURE_SOURCE_OF_TRUTH.md`.
5. `04_UI_UX/UI_UX_SOURCE_OF_TRUTH.md`.
6. Reportes de auditoría de agentes.
7. Propuestas no aprobadas.
8. Mockups y documentos históricos.

### Regla fundamental
Propuesta ≠ decisión ≠ implementación ≠ validación.

Ningún agente puede convertir silenciosamente una recomendación en una decisión.
