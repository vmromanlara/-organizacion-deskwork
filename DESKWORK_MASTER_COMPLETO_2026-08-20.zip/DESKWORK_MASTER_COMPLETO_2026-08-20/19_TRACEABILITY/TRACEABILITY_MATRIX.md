# DeskWork — Traceability Matrix

| Domain | Canonical source | UI representation | Backend/DB | Test |
|---|---|---|---|---|
| Ticket creation | Product | TicketForm | tickets | E2E requester |
| Ticket states | Business Rules | TicketStatus | tickets/events | state transition |
| Priority | Business Rules | PriorityBadge | tickets/events | rule tests |
| SLA | KPI | SLAIndicator | sla clocks | timer tests |
| Permissions | RBAC | action visibility | auth/RLS | security tests |
| Attachments | Security | Attachment control | storage | upload/download tests |
| Comments | Product | Timeline/Activity | comments/events | role tests |
| Dashboard | KPI | KPI cards/tables | queries | metric tests |
| Audit | Business/Security | History | audit/events | integrity tests |
