# DeskWork — Automation Direction

## MVP
Automation should remain lightweight.

Required operational automation:
- SLA warning;
- SLA breach;
- email notification dispatch;
- periodic housekeeping where necessary.

## Outbox
Business transaction creates notification/outbox record.
Worker/job sends email.
Retry must be safe/idempotent.

## n8n
n8n is not a mandatory MVP dependency.
Potential later use:
- integrations;
- external workflows;
- advanced notifications;
- AI-assisted orchestration.

Do not block core ticket functionality on n8n.
