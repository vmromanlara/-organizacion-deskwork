# DeskWork — Supabase Integration Direction

## Expected use
- Auth;
- PostgreSQL;
- Storage;
- RLS.

## Mandatory
All tenant data protected by RLS.
Migrations versioned.
Policies tested.
No privileged service-role usage in normal user requests.

## CLI
The project has previously discussed Supabase CLI installation method as an implementation detail. The exact choice remains an operational setup decision unless explicitly recorded as approved.

## Acceptance
Supabase is not “implemented” because a project exists.
Acceptance requires:
- migrations;
- schema;
- RLS;
- auth flow;
- storage policy;
- tests;
- environment configuration;
- backup/recovery plan.
