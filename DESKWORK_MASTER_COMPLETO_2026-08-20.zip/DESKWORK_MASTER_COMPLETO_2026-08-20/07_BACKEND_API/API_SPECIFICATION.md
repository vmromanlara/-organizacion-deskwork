# DeskWork — API Direction

Prefix: `/api/v1`

## Resources
- auth/session
- tenants
- memberships
- users
- teams
- services
- categories
- tickets
- ticket comments
- ticket events/history
- assignments
- SLA
- attachments
- notifications
- dashboards
- admin settings

## Ticket operations
- create;
- list;
- get;
- comment;
- assign;
- transition;
- resolve;
- close;
- reopen when authorized;
- override priority when authorized;
- attach file.

## Rules
JSON UTF-8.
UTC timestamps.
Cursor pagination where needed.
Opaque cross-tenant errors.
Expected:
401, 403, 404, 409, 422, 429, 500.

## Security
Every mutation:
auth → membership → permission → domain rule → transaction → audit/event.
