# DeskWork — Architecture Source of Truth

## Arquitectura MVP
Preferencia consolidada:
- Next.js;
- TypeScript;
- modular monolith;
- BFF/API routes;
- Supabase;
- PostgreSQL;
- Auth;
- Storage;
- RLS;
- SQL migrations versionadas;
- jobs ligeros;
- outbox para email.

No microservices en MVP.

## Flujo
Browser
→ Next.js frontend
→ BFF/API
→ domain/service layer
→ PostgreSQL/Supabase
→ Storage/Email según necesidad.

## Principio
El frontend no accede a lógica privilegiada para saltarse autorización.

## Tenancy
tenant_id es frontera de seguridad.

## Backend
Debe validar:
- autenticación;
- membership;
- rol;
- permiso;
- alcance;
- transición válida;
- payload.

## Base de datos
No event sourcing.
Mantener estado actual + eventos/auditoría append-only.

## Jobs
Para:
- SLA warnings;
- SLA breach;
- notificaciones pendientes;
- tareas periódicas.

Deben ser idempotentes.

## CI
Debe bloquear merge ante:
- typecheck;
- lint;
- tests;
- migraciones inválidas;
- fallos de seguridad relevantes.
