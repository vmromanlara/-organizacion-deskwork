# DeskWork — Product Source of Truth

## Producto
DeskWork es una plataforma SaaS de soporte interno orientada a organizaciones que necesitan registrar, ordenar, resolver y medir solicitudes de soporte.

### Promesa
Resolver solicitudes de forma simple, medible y trazable.

### Principios
- simplicidad para quien solicita;
- potencia para quien atiende;
- visibilidad para supervisión;
- métricas para gestión;
- automatización progresiva;
- conocimiento operativo acumulable;
- trazabilidad;
- escalabilidad sin complejidad prematura.

## Problema
En organizaciones pequeñas/medianas, soporte suele depender de:
- mensajes;
- correos;
- llamadas;
- conocimiento informal;
- seguimiento manual.

Esto produce pérdida de solicitudes, falta de prioridad objetiva, ausencia de SLA y poca capacidad de medir el servicio.

## Solución
Centralizar solicitudes como tickets con:
- identificación;
- categoría;
- descripción;
- adjuntos;
- prioridad calculada;
- asignación;
- estado;
- SLA;
- historial;
- métricas.

## MVP
### Incluido
- autenticación;
- tenant;
- membresías;
- roles;
- catálogo básico;
- creación de tickets;
- listado;
- detalle;
- comentarios;
- adjuntos;
- seis estados;
- P1-P4;
- prioridad calculada;
- override auditado;
- asignación;
- SLA/timers;
- email;
- dashboard básico;
- auditoría.

### Fuera del MVP
- WhatsApp;
- Teams/Slack;
- n8n como dependencia funcional;
- IA generativa;
- CMDB/inventario;
- knowledge base avanzada;
- proyectos;
- billing SaaS;
- workflow builder complejo;
- permisos completamente personalizados.

## Experiencia requester
1. Ingresar.
2. Identificarse.
3. Seleccionar tipo/categoría.
4. Describir.
5. Adjuntar opcionalmente.
6. Enviar.

No decide:
- prioridad;
- técnico;
- SLA;
- routing.

## Roles MVP
- requester;
- agent;
- supervisor;
- tenant_admin.

Los niveles históricos de negocio pueden utilizarse en UX, pero el modelo técnico debe permanecer controlado.

## Evolución
MVP → expansión operacional → inteligencia asistida → mejora continua → SaaS escalable.
