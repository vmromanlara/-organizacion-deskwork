# Prompt Master — Sequence

## Global instruction
Every agent must read:
1. README_MASTER.md
2. CURRENT_STATUS.md
3. MASTER_RULES.md
4. Product Source of Truth
5. Architecture Source of Truth
6. UI/UX Source of Truth
7. Decision Log
8. Current phase/gates
9. Relevant QA requirements.

## Claude
Audit/refine only UI/UX. Do not redesign product logic.

## Minimax
Audit integration UI/UX ↔ product ↔ architecture ↔ RBAC ↔ SLA. Return conflicts and approvals.

## GPT
Consolidate Minimax findings into canonical decisions. Update decision log and implementation specification.

## Codex
Implement only approved canonical specification. No reinterpretation, no scope expansion. Return implementation evidence and tests.

## Minimax + GPT
Audit implementation against source of truth. Do not close Foundation on visual appearance alone.
