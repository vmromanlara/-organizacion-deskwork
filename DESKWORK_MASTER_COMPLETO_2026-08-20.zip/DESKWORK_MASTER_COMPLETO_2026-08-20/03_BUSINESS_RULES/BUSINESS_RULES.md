# DeskWork — Business Rules

## Ticket
Un ticket representa una solicitud/incidencia trazable.

## Categorías iniciales
- computador/equipo;
- email;
- internet/conectividad;
- impresora;
- telefonía;
- acceso/permisos;
- software/aplicaciones;
- cuenta/usuario;
- otros.

## Estados oficiales MVP
1. ABIERTO
2. EN_PROCESO
3. ESPERANDO_USUARIO
4. ESCALADO
5. RESUELTO
6. CERRADO

No agregar estados sin decisión explícita.

## Transiciones conceptuales
ABIERTO → EN_PROCESO / ESPERANDO_USUARIO / ESCALADO
EN_PROCESO → ESPERANDO_USUARIO / ESCALADO / RESUELTO
ESPERANDO_USUARIO → EN_PROCESO / ESCALADO / RESUELTO
ESCALADO → EN_PROCESO / RESUELTO
RESUELTO → CERRADO / reapertura autorizada
CERRADO → reapertura autorizada.

Toda transición debe ser:
- autorizada;
- registrada;
- auditable.

## Prioridad
P1 Critical
P2 High
P3 Normal
P4 Low

La prioridad es calculada por sistema.

Factores conceptuales:
- cargo;
- tipo de incidencia;
- descripción;
- impacto/alcance.

El cargo por sí solo no determina prioridad.

Override:
- solo rol autorizado;
- requiere motivo;
- queda auditado.

## SLA
Separar:
- primera respuesta;
- tiempo total;
- tiempo efectivo;
- espera requester;
- resolución;
- cumplimiento SLA.

Default:
`ESPERANDO_USUARIO` puede pausar clocks elegibles.
`ESCALADO` no pausa automáticamente.

## Historial
Debe conservar:
- creación;
- cambios de estado;
- cambios de prioridad;
- asignación;
- comentarios;
- solicitudes de información;
- escalamiento;
- resolución;
- cierre;
- reapertura;
- eventos relevantes.

## Comentarios
Separar comentarios públicos de notas internas.
Nunca exponer notas internas al requester.

## Notificaciones
Eventos MVP:
- creación;
- asignación;
- comentario público;
- solicitud de información;
- warning SLA;
- breach SLA;
- resolución;
- cierre.
