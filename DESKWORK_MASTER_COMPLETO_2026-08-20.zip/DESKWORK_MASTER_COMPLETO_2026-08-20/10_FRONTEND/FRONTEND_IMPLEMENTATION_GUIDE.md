# DeskWork — Frontend Implementation Guide

## Principle
Implement the canonical UI/UX specification. Do not redesign while coding.

## Token rule
If a value exists as a token, use the token.
Do not duplicate colors, spacing, radii or typography values.

## State rule
Every interactive component must have defined:
default/hover/focus/active/disabled/loading where applicable.

## Domain rule
UI labels and visual states must map to canonical ticket states, priorities and SLA states.

## Permission rule
The UI may hide/disable actions, but never treats that as security.

## Responsive rule
Mobile-first.

## Accessibility rule
Semantic HTML first.
Labels for controls.
Visible focus.
Keyboard operation.
Accessible errors.
ARIA only when necessary and correctly applied.

## No mock-data rule
Hardcoded mock data may exist only in isolated development fixtures/tests.
Production flows must use real API/data.

## Route direction
/login
/select-tenant
/app
/app/tickets
/app/tickets/new
/app/tickets/:id
/app/admin/users
/app/admin/teams
/app/admin/catalog
/app/admin/sla
/app/admin/settings
