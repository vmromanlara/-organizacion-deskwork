# DeskWork — Decision Log

## Confirmed
1. DeskWork is an internal-support ticketing SaaS.
2. Simplicity is a core product principle.
3. Ticket is the primary operational unit.
4. Requester cannot select priority.
5. Priority is system-calculated P1–P4.
6. Six official MVP states.
7. Ticket history/audit is mandatory.
8. SLA/timers are core MVP functionality.
9. Email is MVP.
10. Basic dashboard is MVP.
11. UI/UX Claude v2.0 is Foundation input.
12. Design tokens are canonical UI source.
13. UI must map to domain/RBAC/SLA truth.
14. Minimax audits integration.
15. GPT consolidates/arbiter.
16. Codex implements canonical spec.
17. Minimax + GPT audit implementation.
18. Dark mode is deferred.
19. Start with 15–20 icons.
20. WCAG AA is a target until tested.
21. ROI percentages from Claude are not validated metrics.
22. UI cannot be security authority.
23. RLS + backend authorization are mandatory.
24. n8n is not an MVP blocker.
25. AI/WhatsApp/CMDB/advanced knowledge/projects/billing are outside MVP by default.

## Pending
- exact auth/identity;
- hosting/region/domain;
- Supabase plan;
- exact P1-P4 calculation thresholds;
- business calendar/holidays;
- exact SLA targets;
- alert thresholds;
- attachment malware scanning;
- privacy/retention;
- RPO/RTO;
- automatic closure/reopen policy;
- supervisor scope.

## Governance
No pending proposal is to be implemented as if confirmed.
