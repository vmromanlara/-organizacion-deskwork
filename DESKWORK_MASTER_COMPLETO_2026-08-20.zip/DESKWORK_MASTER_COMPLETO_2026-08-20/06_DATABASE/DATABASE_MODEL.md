# DeskWork — Database Model

## Núcleo
- tenants
- users/auth identities
- memberships
- roles
- permissions
- membership_roles
- teams
- team_memberships
- services
- categories
- ticket_statuses
- priorities

## Tickets
- tickets
- ticket_comments
- ticket_events
- ticket_assignments
- ticket_sla_clocks
- attachments

## SLA
- sla_policies
- business_calendars
- business_hours
- holiday_dates

## Plataforma
- notifications
- audit_logs

## Reglas
- UUID/IDs consistentes;
- timestamps UTC;
- tenant_id;
- RLS;
- constraints;
- foreign keys;
- índices adecuados;
- append-only audit/event data.

## Historial
ticket_events debe permitir reconstruir la historia operacional del ticket sin necesidad de event sourcing.

## SLA snapshot
El ticket debe conservar el SLA aplicable para que cambios futuros de política no alteren retrospectivamente tickets históricos.
