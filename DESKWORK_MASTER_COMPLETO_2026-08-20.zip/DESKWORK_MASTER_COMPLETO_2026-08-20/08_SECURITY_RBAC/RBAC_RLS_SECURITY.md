# DeskWork — RBAC / RLS / Security

## Roles
requester
agent
supervisor
tenant_admin

## General permissions
Requester:
- create own ticket;
- see own tickets;
- comment public;
- attach allowed files;
- respond to information requests;
- reopen only according to policy.

Agent:
- see assigned/authorized queues;
- work tickets;
- assign where authorized;
- change allowed states;
- comment;
- add internal notes;
- escalate;
- resolve.

Supervisor:
- broader operational visibility;
- supervise queue;
- dashboards;
- escalations;
- operational controls within scope.

Tenant Admin:
- tenant configuration;
- users/memberships;
- teams;
- catalog;
- SLA/configuration where authorized.

## Security principle
Frontend restrictions are UX only.
RLS + backend authorization are mandatory.

## Cross-tenant
Any attempt to:
- read;
- modify;
- enumerate;
- download
another tenant’s data must fail.

## Attachments
Private storage.
Signed short-lived URLs.
Allowlist:
PNG/JPEG/PDF/TXT/CSV/DOCX/XLSX.
No executables/scripts/archives/HTML/SVG as initial policy.
Initial recommendation:
10 MB/file; 5 files/ticket.
Malware scanning/quarantine required before production acceptance.
