# DeskWork — Source Archive Manifest

The definitive master should preserve original files when they are available.

Known historical source classes:
- Documento Maestro DeskWork;
- project memory;
- Source of Truth technical document;
- manual de marca;
- prompt de diseño;
- initial mockup HTML;
- Python extraction scripts;
- Claude Proposal v2.0;
- Claude Specs v2.0;
- Phase 3A report;
- Minimax reports;
- Codex reports;
- prompts used during project development.

## Rule
Do not delete originals after consolidation.
The master uses canonical summaries/specifications, while this archive preserves provenance.
