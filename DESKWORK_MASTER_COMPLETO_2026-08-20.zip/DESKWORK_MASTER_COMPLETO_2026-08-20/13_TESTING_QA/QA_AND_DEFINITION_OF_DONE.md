# DeskWork — QA and Definition of Done

A feature is NOT done because a screen renders.

## Required
- real persistence;
- auth;
- authorization;
- RLS;
- validation;
- error handling;
- tests;
- audit/events where applicable;
- responsive behavior;
- accessibility behavior;
- API contract;
- no secrets;
- CI pass.

## Test layers
1. Unit.
2. Integration.
3. RLS/security.
4. API.
5. E2E by role.
6. Accessibility.
7. Responsive.
8. SLA/timer.
9. Attachment security.
10. Notification idempotency.

## Role E2E
Requester:
create → view → comment → respond → own visibility.

Agent:
queue → assign → transition → comment → resolve.

Supervisor:
visibility → dashboard → escalation.

Admin:
configuration → users → teams → catalog → SLA.

## Gate
Foundation closes only after all critical tests pass or an explicit exception is recorded.
