# DeskWork — Historia y evolución recuperable

## Etapa 0 — Concepto inicial
DeskWork nace como una propuesta de mesa de ayuda/ticketing orientada a soporte TI interno.

La idea inicial era deliberadamente simple:
- el usuario se identifica por email;
- crea una incidencia;
- selecciona una categoría;
- describe el problema;
- adjunta una imagen cuando sea necesario;
- envía;
- el sistema determina la prioridad;
- el técnico recibe/gestiona el ticket;
- el sistema mide tiempos y KPIs.

El principio inicial fue evitar un sistema pesado de ITSM.

## Etapa 1 — Primer mockup
El repositorio inicial estaba compuesto esencialmente por:
- HTML;
- CSS;
- JavaScript vanilla;
- datos hardcodeados;
- mockup visual;
- documentación;
- scripts Python para extracción documental.

No existían:
- backend funcional;
- base de datos;
- autenticación;
- persistencia;
- Supabase;
- n8n;
- ngrok;
- flujo real de tickets.

La estimación histórica de madurez del MVP era aproximadamente 2%.

Conclusión: el mockup era una referencia visual, no una aplicación funcional.

## Etapa 2 — Documentación y formalización
Se consolidaron:
- visión;
- modelo funcional;
- roles;
- estados;
- prioridad;
- SLA;
- dashboard;
- arquitectura;
- seguridad;
- multi-tenancy;
- base de datos;
- API;
- criterios de QA.

Se comenzó a tratar DeskWork como un producto SaaS real y no solamente como un mockup.

## Etapa 3 — Trabajo multiagente
El proyecto comenzó a distribuirse entre:
- Claude: diseño y propuesta UI/UX;
- Minimax: análisis, auditoría e implementación/revisión;
- Codex: arquitectura/código/validación técnica;
- GPT: consolidación, razonamiento de producto y arbitraje.

La necesidad detectada fue evitar que cada agente trabajara sobre una interpretación diferente.

## Etapa 4 — Foundation / Fase 3A
Codex revisó la Foundation y determinó que no debía autorizarse automáticamente la siguiente fase hasta cerrar correctamente la anterior.

La regla pasó a ser:
Foundation creada ≠ Foundation cerrada.

## Etapa 5 — Claude UI/UX v2.0
Claude entregó una propuesta de Design System:
- tokens centralizados;
- componentes interactivos;
- iconografía;
- accesibilidad;
- responsive;
- estados;
- paleta semántica;
- frontend guide.

La evaluación posterior determinó que la propuesta es buena como Foundation UI/UX, pero no debe convertirse directamente en roadmap del producto.

## Etapa 6 — Integración UI/UX ↔ producto
Se acordó:
Claude → Foundation visual  
Minimax → auditoría de integración  
GPT → consolidación canónica  
Codex → implementación  
Minimax + GPT → auditoría de implementación.

La UI debe representar:
- tickets;
- estados;
- prioridades;
- SLA;
- permisos;
- auditoría;
- datos reales.

No debe inventar reglas de negocio.

## Estado actual
DeskWork está en transición entre Foundation y construcción funcional del MVP.

La prioridad inmediata es cerrar:
- Foundation;
- decisiones técnicas pendientes;
- integración UI/UX;
- permisos;
- workflow;
- SLA;
- implementación controlada.

No corresponde volver a rediseñar el producto desde cero.
