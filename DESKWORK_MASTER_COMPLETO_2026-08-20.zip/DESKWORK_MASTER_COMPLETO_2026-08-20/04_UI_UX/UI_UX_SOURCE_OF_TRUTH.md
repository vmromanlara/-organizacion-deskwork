# DeskWork — UI/UX Source of Truth v2.0

## Origen
Integración de la propuesta de Claude v2.0 con el modelo funcional y técnico de DeskWork.

## Decisiones
### Mantener
- identidad teal;
- Outfit;
- JetBrains Mono;
- tokens;
- spacing;
- radius;
- responsive;
- accesibilidad como objetivo;
- estados de interacción;
- componentes base;
- paleta semántica.

### Modificar
- iconos: iniciar con 15–20;
- WCAG: “diseñado para WCAG 2.1 AA”, no “cumple” hasta test;
- ROI: no tratar porcentajes como métricas demostradas;
- roadmap UI: no convertirlo en roadmap general del producto.

### Post-MVP
- dark mode;
- expansión grande de iconografía;
- Storybook obligatorio;
- sincronización Figma como blocker.

## Tokens
Paleta:
primary 500 #0d4f4a
primary 600 #0a3d39
accent 500 #6ee7df
bg #fafaf7
surface #ffffff
line #e9e3d6
ink #14171e
ink-2 #3a4256
muted #7c7a72
critical #b3331f
high #c2410c
normal #a16207
low #047857
success #059669
warning #d97706
info #1d4ed8
error #dc2626

Spacing:
4, 8, 16, 24, 32, 48, 80.

Typography:
Outfit / JetBrains Mono.

## Componentes base
Button, Input, Textarea, Select, Checkbox, Badge, Card, Modal, Toast, Alert, Loading, Skeleton, Table, Pagination, Avatar, Dropdown, Attachment.

## Componentes DeskWork
TicketForm
TicketCard
TicketStatus
PriorityBadge
SLAIndicator
AssignmentSelector
TicketTimeline
TicketActivity
EmptyState
ErrorState.

## Estados
Button:
default, hover, active, focus, disabled, loading.

Input:
empty, filled, focus, invalid, valid, disabled, readonly, loading.

## Ticket UI
La interfaz debe reflejar exclusivamente los seis estados oficiales.

## Priority UI
La prioridad mostrada debe ser la calculada por sistema.
No pedir prioridad al requester.

## SLA UI
Mostrar:
- objetivo;
- restante;
- warning;
- breach;
- pausa;
- total;
- efectivo.

## RBAC UI
UI puede:
- ocultar;
- deshabilitar;
- mostrar read-only;
- mostrar editable.

Pero seguridad real = backend + RLS.

## Responsive
Mobile-first.
320+ base
768+ tablet
1024+ desktop
1400+ wide.

## Accesibilidad
Target WCAG 2.1 AA.
Testing obligatorio antes de afirmar cumplimiento.

## Corrección técnica
No usar declaraciones CSS inválidas como `font: var(--size-base)`.
Usar propiedades tipográficas válidas o tokens compuestos válidos.
