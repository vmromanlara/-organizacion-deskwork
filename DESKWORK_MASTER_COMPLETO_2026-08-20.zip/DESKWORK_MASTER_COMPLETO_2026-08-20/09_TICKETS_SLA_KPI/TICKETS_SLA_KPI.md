# DeskWork — Tickets, SLA and KPI

## Operational clocks
Track:
- created_at;
- first response;
- effective work;
- requester waiting;
- resolution;
- closure;
- total duration.

## SLA
Use intervals/clocks, not only due_date.
Alerts:
- approaching target;
- breach.

Alerts must be idempotent.

## KPIs
### Technical
- open;
- in process;
- waiting requester;
- escalated;
- overdue;
- critical;
- workload;
- first response;
- resolution;
- SLA compliance.

### Management
- ticket volume;
- resolved/pending;
- SLA;
- average response;
- average resolution;
- distribution by category;
- distribution by priority;
- critical cases.

## KPI integrity
No dashboard metric without:
- definition;
- source event/data;
- time window;
- tenant scope;
- test.
